import React from 'react'

function DeleteBlogs() {
  return (
    <>
       
    </>
  )
}

export default DeleteBlogs